

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAO0ADOWyQqPhEQHBY9sluBZktyBJiK8ZA",
  authDomain: "qriffy-49d7b.firebaseapp.com",
  projectId: "qriffy-49d7b",
  storageBucket: "qriffy-49d7b.firebasestorage.app",
  messagingSenderId: "780685517256",
  appId: "1:780685517256:web:1961ee0005895e8e16e0fd"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
