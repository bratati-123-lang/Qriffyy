import { configureStore } from "@reduxjs/toolkit";
import qrHistoryReducer from "../features/qrHistory/qrHistorySlice";

export const store = configureStore({
  reducer: {
    qrHistory: qrHistoryReducer,
  },
});
