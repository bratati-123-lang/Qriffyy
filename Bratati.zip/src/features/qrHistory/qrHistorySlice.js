import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  qrHistoryData: [],
};

const qrHistorySlice = createSlice({
  name: "qrHistory",
  initialState,
  reducers: {
    addQrHistory: (state, action) => {
      state.qrHistoryData.unshift(action.payload);
    },
    deleteQrHistory: (state, action) => {
      state.qrHistoryData = state.qrHistoryData.filter(
        (_, index) => index !== action.payload
      );
    },
  },
});

export const { addQrHistory, deleteQrHistory } = qrHistorySlice.actions;

export default qrHistorySlice.reducer;
