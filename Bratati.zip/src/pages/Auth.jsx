import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  createUserWithEmailAndPassword,// firebase authentication theke signup kora holo with email and password
  signInWithEmailAndPassword, //login a dewa hobe check a sign up er email r password
} from "firebase/auth";
import { auth } from "../firebase"; //  Firebase configuration থেকে auth object import করা হলো যা দিয়ে authentication কাজ হবে।

function Auth() {

  const navigate = useNavigate(); // route a convert korte hobe 

  const [isSignup, setIsSignup] = useState(true);// initial stage jodi true thale tahole signup nahole login
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!email || !pass) {
      alert("Email and Password required!");
      return;
    }
    //jodi try catch na use kori oi firebase a thaka abuild in functions jodi login ba signup a korte giye kono error khai
    //then user k white screen show korbe else try catch lagale amra app crash na kore smoothly cholbe.
    try {
      if (isSignup) {
        await createUserWithEmailAndPassword(auth, email, pass); // new user hobe
        // create withEmail and password firebase a  promise return korche jeta server a request patahche response aanteo time lagche
        alert("Signup successful!");
      } else {
        await signInWithEmailAndPassword(auth, email, pass); // nahole login
        //Eta Firebase Authentication er built-in function.
      }
      navigate("/dashboard"); // after login sucessfull hole dashboard a navigate kore dao
    } catch (error) {
      alert(error.message);
    }
  };

  return (
    <div className="min-h-screen relative flex justify-center items-center overflow-hidden pt-24 px-4">

      <style>{`
        .sky-bg {
          background: linear-gradient(180deg, #87ceeb, #4a90e2, #1a2a6c);
        }
      `}</style>

      <div className="sky-bg absolute inset-0"></div>

      <div className="bg-white/15 backdrop-blur-2xl border border-white/30 p-10 rounded-2xl shadow-2xl w-full max-w-sm text-white relative z-10">

        <h2 className="text-4xl font-bold text-center mb-8">
          {isSignup ? "Create Account" : "Welcome Back"}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-5">

          <input
            type="email"
            placeholder="Email"
            className="w-full px-4 py-2 rounded-lg bg-white/20 text-white placeholder-white/70 border border-white/40 focus:outline-none focus:border-white"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <input
            type="password"
            placeholder="Password"
            className="w-full px-4 py-2 rounded-lg bg-white/20 text-white placeholder-white/70 border border-white/40 focus:outline-none focus:border-white"
            value={pass}
            onChange={(e) => setPass(e.target.value)}
          />

          <button
            type="submit"
            className="w-full py-2 rounded-lg bg-blue-500 hover:bg-blue-600 text-white font-semibold shadow-md transition"
          >
            {isSignup ? "Sign Up" : "Login"}
          </button>
        </form>

        <p
          onClick={() => setIsSignup(!isSignup)}
          className="text-center mt-6 cursor-pointer hover:underline"
        >
          {isSignup
            ? "Already have an account? Login"
            : "Create a new account"}
        </p>
      </div>
    </div>
  );
}

export default Auth;
