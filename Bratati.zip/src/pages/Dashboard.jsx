import React, { useState } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { useNavigate } from "react-router-dom";
import { signOut } from "firebase/auth";
import { auth } from "../firebase";

import { useDispatch, useSelector } from "react-redux";
import { addQrHistory } from "../features/qrHistory/qrHistorySlice"; // ata reducer a data rakhbe

export default function Dashboard() {
  const [inputText, setInputText] = useState("");
  const [qrText, setQrText] = useState(""); // jakhne qr dekhabe okhn ta
  const [open, setOpen] = useState(false); //side bar open

  const dispatch = useDispatch();
  const history = useSelector((state) => state.qrHistory.qrHistoryData); //store theke data newa

  const navigate = useNavigate(); 

  const generateQR = () => {
    if (!inputText.trim()) {
      alert("Please enter text or URL");
      return;
    }

    setQrText(inputText);

    dispatch(
      addQrHistory({
        id: Date.now(),//
        value: inputText, //Redux-এ নতুন history item যোগ করা হলো:
      })//id = current timestamp

    );

    setInputText(""); //input box খালি করে দেয়া।
  };

  const handleLogout = async () => {
    await signOut(auth); //user k signout hole pathiye dei
    navigate("/"); //abr auth page e
  };

  const downloadQR = () => {
    const canvas = document.querySelector("canvas");
    const imageURL = canvas.toDataURL("image/png");//png a convert kora url take

    const link = document.createElement("a");
    link.href = imageURL;
    link.download = "qr-code.png";//png format a bola holo browser k qr ta save krote 
    link.click();// broweser a click korlei download hoy ota
  };

  return (
    <div
      className="
      min-h-screen flex relative overflow-hidden
      bg-gradient-to-br from-blue-50 via-indigo-100 to-purple-100
    "
    >

      {/* Soft glowing background circle */}
      <div className="absolute inset-0 -z-10 flex items-center justify-center">
        <div className="w-[600px] h-[600px] bg-purple-300/30 rounded-full blur-3xl"></div>
      </div>

      {/* Hamburger */}
      <button
        className={`text-3xl p-3 fixed top-4 bg-white rounded-xl shadow-xl z-50 border transition-all duration-300 hover:bg-gray-100
          ${open ? "left-80" : "left-4"}`}
        onClick={() => setOpen(!open)}
      >
        ☰
      </button>

      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 h-full w-72 bg-white shadow-2xl border-r transition-transform duration-300 z-40
        ${open ? "translate-x-0" : "-translate-x-full"}`}
      >
        <h2 className="text-2xl font-bold p-5 border-b bg-gray-100 shadow-sm">
          History
        </h2>

        <div className="p-4 overflow-y-auto h-[90vh] space-y-4">
          {history.length === 0 && (
            <p className="text-gray-500 text-center">No history yet</p>
          )}

          {history.map((item) => (
            <div
              key={item.id}
              className="border rounded-xl p-4 bg-gray-50 shadow hover:shadow-md transition"
            >
              <p className="text-sm font-semibold mb-3 text-gray-700">
                {item.value}
              </p>
              <div className="flex justify-center">
                <QRCodeCanvas value={item.value} size={70} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Logout */}
      <button
        onClick={handleLogout}
        className="absolute top-4 right-5 px-6 py-2 bg-red-600 text-white rounded-lg shadow-lg font-semibold hover:bg-red-700 transition"
      >
        Logout
      </button>

      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6">

        <h1 className="text-5xl font-extrabold mb-8 text-gray-800 tracking-wide drop-shadow-md">
          QR Code Generator
        </h1>

        <div className="flex gap-4 w-full max-w-xl">
          <input
            type="text"
            placeholder="Enter text or URL..."
            className="flex-1 px-4 py-3 border rounded-xl shadow-md bg-white focus:ring-2 focus:ring-blue-400 focus:outline-none text-gray-700"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
          />

          <button
            onClick={generateQR}
            className="px-6 py-3 bg-blue-600 text-white rounded-xl shadow-md font-semibold hover:bg-blue-700 hover:shadow-lg transition"
          >
            Generate
          </button>
        </div>

        <div className="mt-10 p-8 border rounded-2xl shadow-2xl bg-white/80 backdrop-blur-sm flex flex-col items-center gap-6">
          {qrText ? (
            <>
              <QRCodeCanvas value={qrText} size={230} />

              {/* ⭐ Download Button Added Here */}
              <button
                onClick={downloadQR}
                className="px-6 py-2 bg-green-600 text-white rounded-xl shadow-lg font-semibold hover:bg-green-700 transition"
              >
                Download PNG
              </button>
            </>
          ) : (
            <p className="text-gray-600 text-lg">Your QR will appear here</p>
          )}
        </div>

      </div>
    </div>
  );
}
